 abstract class Customer extends MenuItem {

    private String name;
    private boolean student;
    private int loyaltyPoints;


    public Customer() {
        this.name = "Unknown Customer";
        this.student = false;
        this.loyaltyPoints = 0;
    }


    public Customer(String name) {
        this.name = name;
        this.student = false;
        this.loyaltyPoints = 0;
    }


    public Customer(String name, boolean student) {
        this.name = name;
        this.student = student;
        this.loyaltyPoints = 0;
    }


    public void addPoints(int points) {

        if (points > 0) {
            loyaltyPoints += points;
        } else if (points < 0) {
            System.out.println("Points cannot be negative.");
        }
    }


    public void addPoints(double amountSpent) {

        if (amountSpent >= 0) {
            int points = (int) (amountSpent / 50);
            loyaltyPoints += points;
        } else {
            System.out.println("Invalid amount spent.");
        }
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {

        if (name != null && !name.isEmpty()) {
            this.name = name;
        }
    }


    public boolean isStudent() {
        return student;
    }


    public void setStudent(boolean student) {
        this.student = student;
    }


    public int getLoyaltyPoints() {
        return loyaltyPoints;
    }


    public void setLoyaltyPoints(int loyaltyPoints) {

        if (loyaltyPoints >= 0) {
            this.loyaltyPoints = loyaltyPoints;
        } else {
            System.out.println("Loyalty points cannot be negative.");
        }
    }
}